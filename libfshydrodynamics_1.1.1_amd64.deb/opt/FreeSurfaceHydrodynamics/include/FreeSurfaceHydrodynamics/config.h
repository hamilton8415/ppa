#ifndef _CONFIG_H
#define _CONFIG_H

#define PROJECT_NAME "FreeSurfaceHydrodynamics"
#define PROJECT_VER  "1.1.1"
#define PROJECT_VER_MAJOR 1
#define PROJECT_VER_MINOR 1
#define PROJECT_VER_PATCH 1

#endif // _CONFIG_H 
