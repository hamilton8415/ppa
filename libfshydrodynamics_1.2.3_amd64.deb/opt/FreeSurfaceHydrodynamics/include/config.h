#ifndef _CONFIG_H
#define _CONFIG_H

#define PROJECT_NAME "FreeSurfaceHydrodynamics"
#define PROJECT_VER  "1.2.3"
#define PROJECT_VER_MAJOR 1
#define PROJECT_VER_MINOR 2
#define PROJECT_VER_PATCH 3

#endif // _CONFIG_H 
