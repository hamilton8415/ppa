#ifndef _CONFIG_H
#define _CONFIG_H

#define PROJECT_NAME "FreeSurfaceHydrodynamics"
#define PROJECT_VER  "1.3.0"
#define PROJECT_VER_MAJOR 1
#define PROJECT_VER_MINOR 3
#define PROJECT_VER_PATCH 0

#endif // _CONFIG_H 
